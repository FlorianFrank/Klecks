Makefile hinzugefügt, welches das Programm automatisch erzeugt
Rotieren, Skalieren und Farbe wählen hinzugefügt